%% Script der tester funktioner:
%% Test af (3/4)^1/4
nthroot(3/4,1/4)
%% Test af (5.17)^1/7
nthroot(5.17,1/7)
%% Test af e^1/9
nthroot(exp(),1/9)
%% Test af eksemplerne
nthroot(8,3)
nthroot(82.5,6)