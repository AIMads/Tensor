% Opgave 6 Matlab (42 Point)
function[] = nthroot
    for i = 1:length(a)
        formel = x(i+1)== 1/n(a/x(i)^(n-1)+(n-1)*x(i));  
    % Ideen her var at x(i) er x-koordinatet og x(i+1) er y koordinatet,
    % som arbejder ud fra formel, det skulle s� plottes, men kan ikke f�
    % det til at lykkedes.
    end
    if x(i) == x(i+1)
     stop(t)
        
    end
    